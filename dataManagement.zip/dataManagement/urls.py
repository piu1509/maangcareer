from django.urls import path
from .views import *

urlpatterns = [
    path('login/', DataEntryUserLoginView.as_view(), name='data-entry-user-login'),   
    path('verify-otp/', DataEntryUserOTPVerificationView.as_view(), name='verify_otp-for-data-entry-user'),

    path('course-list/', PaidCourseListAPI.as_view(), name='course-list-for-data-entry'),
    path('batch-list/', PaidBatchListAPI.as_view(), name='batch-list-for-data-entry'),
    
]
