from django.contrib.auth import login
from django.contrib.auth.models import User
from userManagement.models import *
from rest_framework import status

from rest_framework.serializers import ValidationError
from rest_framework.permissions import AllowAny
from rest_framework import serializers
from knox.views import LoginView as KnoxLoginView
from django_otp.oath import TOTP
from django.core.mail import send_mail
from django_otp.plugins.otp_totp.models import TOTPDevice
import hashlib
from rest_framework.response import Response
from django.contrib.auth import authenticate
from knox.models import AuthToken
import time
from knox.auth import TokenAuthentication
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.permissions import IsAuthenticated
from courseManagement.models import *
from rest_framework.views import APIView
from rest_framework.pagination import PageNumberPagination
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from courseManagement.helpers import send_mail_for_otp, send_mail_for_welcome, send_mail_for_reset_password
from rest_framework.exceptions import APIException

# Create your views here.

class GeneratingOTP:
    def __init__(self, email, extra_key, user=None):
        if not user:
            user = User.objects.get(email__iexact=email)
        self.user = user
        hex_email = self.generate_hex(
            self.user.email or self.user.phone_number.as_e164, 20
        )
        hex_extra_key = self.generate_hex(extra_key, 20)
        self.key = f"{hex_email}{hex_extra_key}"
        self.number_of_digits = 6
        # validity period of a token. Default is 30 second.
        self.token_validity_period = 3 * 60

    @staticmethod
    def generate_hex(value, length):
        sha256_hash = hashlib.sha256(value.encode()).hexdigest()
        hex_string = sha256_hash[:length]
        return hex_string

    def totp_device(self):
        totp_device, created = TOTPDevice.objects.update_or_create(
            key=self.key,
            user=self.user,
            defaults={
                "step": self.token_validity_period,
                "digits": self.number_of_digits,
                "tolerance": 0,
            },
        )
        return totp_device

    def totp_obj(self):
        totp_device = self.totp_device()
        # create a TOTP object
        totp = TOTP(
            key=totp_device.bin_key,
            step=totp_device.step,
            t0=totp_device.t0,
            digits=totp_device.digits,
            drift=totp_device.drift,
        )
        return totp

    def generate_otp(self):
        # get the TOTP object and use that to create token
        totp = self.totp_obj()
        token = totp.token()
        return str(token).zfill(self.number_of_digits)

    def verify_otp(self, token):
        # verify otp using totp device
        totp_device = self.totp_device()
        is_verified = totp_device.verify_token(token)
        if is_verified:
            totp_device.delete()
        return is_verified


def generate_otp_for_mail(
        email: str,
        extra_key: str,
) -> bool:
    """Generate OTP for Phone Number"""
    generate_otp_service = GeneratingOTP(email, extra_key)

    return generate_otp_service.generate_otp()

class CustomValidationError(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'A validation error occurred.'
    default_code = 'invalid'

    def __init__(self, detail, code=None):
        self.detail = detail
        self.code = code

class CustomAuthTokenSerializer(serializers.Serializer):
    username = serializers.CharField(
        label="Username",
        write_only=True
    )
    password = serializers.CharField(
        label="Password",
        style={'input_type': 'password'},
        trim_whitespace=False,
        write_only=True
    )

    def validate(self, attrs):
        username = attrs.get('username')
        password = attrs.get('password')
        
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            raise CustomValidationError({"status": "400", "message": "User Does not exist"})
        
        if not user.check_password(password):
            raise CustomValidationError({"status": "400", "message": "Incorrect Credentials"})
        
        if not user.is_active:
            otp = generate_otp_for_mail(user.email, "login")
            send_mail_for_otp(user.email, otp)
            raise CustomValidationError({"status": "400", "message": "User Not Verified"})
        
        otp = generate_otp_for_mail(user.email, "login")
        send_mail_for_otp(user.email, otp)

        data_entry_user = DataEntryUser.objects.filter(user=user).first()
        if data_entry_user:
            data_entry_user.otp = otp
            data_entry_user.otp_validation_time = timezone.now() + timedelta(minutes=5)
            data_entry_user.save()
        
        return {
            "username": username,
            "otp_sent": True,
            "message": "OTP sent successfully."
        }


class DataEntryUserOTPVerificationView(KnoxLoginView):
    permission_classes = (AllowAny,)

    def post(self, request):
        otp = request.data.get('otp')
        username = request.data.get('username')
        
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            return Response({"status": status.HTTP_400_BAD_REQUEST, "message": "User does not exist."})
        
        data_entry_user = DataEntryUser.objects.filter(user=user).first()
        if data_entry_user:
            if data_entry_user.otp == int(otp) and data_entry_user.otp_validation_time >= timezone.now():
                # OTP is valid, generate token
                login(request, user)
                return super().post(request)
            else:
                return Response({"status": status.HTTP_400_BAD_REQUEST, "message": "Invalid OTP or OTP expired."})
        else:
            return Response({"status": status.HTTP_400_BAD_REQUEST, "message": "User is not a Data Entry User."})
                 

class DataEntryUserLoginView(KnoxLoginView):
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        
        username = request.data.get('username')
        password = request.data.get('password')        
       
        serializer = CustomAuthTokenSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        validated_data = serializer.validated_data

        # Return response indicating OTP has been sent
        return Response({
            "status": status.HTTP_200_OK,
            "message": "OTP sent to your email.",
            "otp_sent": validated_data.get("otp_sent")
        })



class CustomCourseListSerializer(serializers.ModelSerializer):
    batch_complemted = serializers.SerializerMethodField()
    batch_ongoing = serializers.SerializerMethodField()

    class Meta:
        model = Course
        fields = (           
            
            "id",            
            "name",
            "course_duration_in_months",        
                     
            "batch_complemted",
            "batch_ongoing"
                       
        )
    def get_batch_complemted(self, obj):
        # Count the completed batches for this course
        return obj.batches.filter(completed=True).count()

    def get_batch_ongoing(self, obj):
        # Count the ongoing (not completed) batches for this course
        return obj.batches.filter(completed=False).count()


class PaidCourseListAPI(APIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        queryset = Course.objects.filter(archive=False)
        serializer = CustomCourseListSerializer(queryset, many=True)
        return Response(serializer.data)
    

class CustomBatchListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Batch
        fields = (
            "id",
            "name",
            "course",
            "instructor",
            "enrolled",
            "start_date",
            "end_date",
            "completed"
        )

class PaidBatchListAPI(APIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated,)

    def get(self, request):
       
        course_name = request.GET.get('course_name', None)
        start_date = request.GET.get('start_date', None)
        completed = request.GET.get('completed', None)  
        page = request.GET.get('page', 1)  
        page_size = request.GET.get('page_size', 5)  

        try:
            page_size = int(page_size)
            if page_size <= 0:
                raise ValueError
        except (ValueError, TypeError):
            return Response({"message": "Invalid page size. It must be a positive integer.", "status":status.HTTP_400_BAD_REQUEST})      
        
        queryset = Batch.objects.filter(course__archive=False)
        
        if course_name:
            queryset = queryset.filter(course__name__icontains=course_name)  

        if start_date:
            queryset = queryset.filter(start_date=start_date)  

        if completed is not None:
            
            if completed.lower() in ['true', 'false']:
                queryset = queryset.filter(completed=completed.lower() == 'true')
            else:
                return Response({"message": "Invalid value for 'completed' filter. Use 'true' or 'false'.", "status":status.HTTP_400_BAD_REQUEST})


        paginator = PageNumberPagination()
        paginator.page_size = page_size  
        paginated_queryset = paginator.paginate_queryset(queryset, request)
        serializer = CustomBatchListSerializer(paginated_queryset, many=True)

        return paginator.get_paginated_response(serializer.data)

