from django.urls import path
from .views import *

urlpatterns = [
    path('login/', SubAdminLoginView.as_view(), name='sales-admin-login'),    
    path('verify-otp/', SubAdminOTPVerificationView.as_view(), name='verify_otp-for-admin-sale'),

    path('course-list/', PaidCourseList.as_view(), name='course-list-for-admin-sale'),
    path('batch-list/', PaidBatchList.as_view(), name='batch-list-for-admin-sale'),
    path('add-batch/', AddBatch.as_view(), name='add-batch-for-admin-sale'),
    path('preview-add-batch/', PreviewAddBatch.as_view(), name='preview-add-batch-for-admin-sale'),
    path('batch-details/', BatchDetailsView.as_view(), name='batch-details-for-admin-sale'),
    
]
